import numpy as np

def idonothing(Yc: np.ndarray) -> np.ndarray:
	return Yc

def donothing(Yc: np.ndarray) -> np.ndarray:
	return Yc